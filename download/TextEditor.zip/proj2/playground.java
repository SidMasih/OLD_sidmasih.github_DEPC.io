import java.util.ArrayList;

/**
 * Created by sidmasih on 2/28/16.
 */
public class playground {
    public static void main(String [] CS) {

        ArrayList<Integer> x = new ArrayList<>();

        x.add(5345345);
        x.add(5345345);
        x.add(1);
        x.add(2);

        x.add(1,5345345);
        x.add(1,5345345);
        x.add(69);
        x.add(5345345);
        x.add(5345345);

        for (int i = 0; i < x.size(); i++) {

            int eecs = x.get(i);

            if (eecs == 5345345) {
                x.remove(i);

                while(i < x.size() && x.get(i) == 5345345 ) {
                    x.remove(i);
                }
            }


        }

        for (int i : x) {
            System.out.println(i);
        }



    }

}


//if( new_width > window_width) {
  //      scrollbar.setLayoutX(newScreenWidth.doubleValue() - scrollbar.getLayoutBounds.().getWidth())
    //    }