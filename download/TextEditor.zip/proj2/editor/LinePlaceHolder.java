package editor;

/**
 * Created by sidmasih on 2/28/16.
 */
public class LinePlaceHolder {



    private EditorCharecter NL;

    private boolean isWordWrap = false;

    /**
     * main constructor
     *
     * @param x holds index o
     */
    public LinePlaceHolder(EditorCharecter x) {
        NL = x;
    }

    /**
     * used when wordwrap demands a new line
     * @param mainlineIndex parent NL
     * @param x holds temporary \r for word wrap
     * @param isWW true if the new line is word wrap only
     */
    public LinePlaceHolder(int mainlineIndex, EditorCharecter x, boolean isWW) {

        NL = x;

        isWordWrap = isWW;
    }



    public EditorCharecter getNL() {
        return NL;
    }

    public boolean isWordWrap() {
        return isWordWrap;
    }
}
