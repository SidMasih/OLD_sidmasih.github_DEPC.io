package editor;

/**
 * Created by sidmasih on 2/26/16.
 * container that contains the charecter in the editor
 */
public class EditorCharecter {


    private String myChar;
    private int pixelsize;
    private boolean isSentinal;
    private boolean isSelect;

    private boolean iswrapped = false;

    EditorCharecter next;
    EditorCharecter prev;


    /**
     *
     * @param pixelsize
     * @param myChar
     */

    public EditorCharecter(String myChar, int pixelsize) {

        this.myChar = myChar;
        this.pixelsize = pixelsize;
        this.isSentinal = false;

    }

    public boolean iswrapped() {
        return iswrapped;
    }

    /**
     *
     * @param pixelsize
     * @param myChar
     */

    public EditorCharecter(String myChar, int pixelsize, boolean iswrapped) {

        this.myChar = myChar;
        this.pixelsize = pixelsize;
        this.isSentinal = false;
        this.iswrapped = iswrapped;


    }

    /**
     * only used for creating sentinals
     *
     */
    public EditorCharecter() {
        this.pixelsize = 0;
        this.myChar = "";
        this.isSentinal = true;



    }

    @Override
    public String toString() {
        return myChar;
    }


    public int getPixelsize() {
        return pixelsize;
    }

    public void setPixelsize(int num) {
        pixelsize = num;
    }


    public boolean isSentinal() {
        return isSentinal;
    }

    public boolean isSelected() {
        return isSelect;
    }

    public void setSelect(boolean choice) {
        this.isSelect = choice;
    }


}
