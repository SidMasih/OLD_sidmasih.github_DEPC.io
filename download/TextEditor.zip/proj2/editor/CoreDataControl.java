package editor;


import javafx.geometry.VPos;
import javafx.scene.text.Font;
import javafx.scene.text.Text;


import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.NoSuchElementException;

/**
 * Created by sidmasih on 2/26/16.
 * manager of the text stored in the data in ram
 */
public class CoreDataControl {
    private final String fonttype = "Verdana";
    private int fontsize = 12;
    private int fontHeight;



    private ArrayDeque<UndoRedoContainer> undo;
    private ArrayDeque<UndoRedoContainer> redo;

    private EditorCharecter masterLink; //firstLink and is a sentinal NEVER TOUCH!
    private EditorCharecter currentLink; // one that holds current link


    //holds indexes representing the start of new lines
    private ArrayList<LinePlaceHolder> lineList;
    private int linenum = 0;


    public CoreDataControl() {
        lineList = new ArrayList<LinePlaceHolder>();

        EditorCharecter topSent = new EditorCharecter();
        EditorCharecter botSent = new EditorCharecter();

        topSent.next = botSent;
        botSent.next = null;

        topSent.prev = null;
        botSent.prev = topSent;

        masterLink = topSent;
        currentLink = topSent;

        undo = new ArrayDeque<>();
        redo = new ArrayDeque<>();

        lineList.add(new LinePlaceHolder(topSent));
        linenum++;
    }
    public int calcMaxLineNumber() {
        return lineList.size();
    }
    public void setFontsize(int font) {
        EditorCharecter e = masterLink;

        fontsize = font;

        e = e.next;

        while (!e.isSentinal() && !e.next.isSentinal()) {
            if (!e.toString().equals("\r")) {
                e.setPixelsize(setPixWidth(e.toString()));
            }
            e = e.next;
        }
    }

    /**
     * MAY REQUIRE ADJUSTING LATER
     * during resize operations new lines must be accounted for by the controller
     *
     * @return pixel location for cursor including WW
     */
    public int cursorLocationMove(int linenumber, int pixelSideways) {


        if (linenumber > lineList.size() - 1) {

            linenumber = lineList.size() - 1;
        } else if (linenumber < 0) {
            linenumber = 0;
        }

        if (pixelSideways <= lineList.get(linenumber).getNL().next.getPixelsize()) {

            currentLink = lineList.get(linenumber).getNL();
            linenum = linenumber + 1;
            return 0;
        }

        linenum = linenumber + 1;
        int pixels = 0;


        LinePlaceHolder holder = lineList.get(linenumber);
        EditorCharecter nl = holder.getNL();





        while (!nl.next.isSentinal() && !nl.next.toString().equals("\r") && pixelSideways > 0) {

            int charpix = nl.getPixelsize();
            pixelSideways = pixelSideways - charpix;

            pixels = pixels + charpix;
            nl = nl.next;
        }


        if (!nl.next.iswrapped() && nl.next.toString().equals("\r")) {
            currentLink = nl;

        } else if (nl.next.toString().equals("\r")) {
            currentLink = nl.prev;
        } else if (nl.equals("\r") && nl.next.equals("\r") && nl.prev.equals("\r")) {
            currentLink = nl.prev;
        } else {
            currentLink = nl;

        }

        return 0;


    }


    /**
     * Used for paste and file read
     *
     * @param s a string with more charecters than 1
     */
    public void insertLargeString(String s, boolean wp) {

        for (char c : s.toCharArray()) {
            if (c == '\n') {
                insert("\r", false);
            }
            insert(String.valueOf(c), wp);
        }
    }


    /**
     * @param s only a charecter or \r
     */
    public void insert(String s, boolean wp) {
        try {
            if (redo.size() != 0) {
                redo = new ArrayDeque<UndoRedoContainer>();
            }
            if (s.equals("\r")) {

                if (undo.size() <= 100) {
                    undo.push(new UndoRedoContainer("insert", "\r"));
                }

                EditorCharecter newChar = new EditorCharecter("\r", 0);

                EditorCharecter savedPrev = currentLink.next;
                currentLink.next = newChar;


                newChar.prev = currentLink;
                newChar.next = savedPrev;
                savedPrev.prev = newChar;


                currentLink = newChar;


                if (linenum < lineList.size() - 1) {
                    lineList.add(linenum + 1, new LinePlaceHolder(currentLink));
                } else {
                    lineList.add(new LinePlaceHolder(currentLink));
                }

                linenum++;


            } else {

                if (undo.size() <= 100) {
                    undo.push(new UndoRedoContainer("insert", s));
                }

                EditorCharecter newChar = new EditorCharecter(s, setPixWidth(s));

                EditorCharecter savedPrev = currentLink.next;
                currentLink.next = newChar;


                newChar.prev = currentLink;
                newChar.next = savedPrev;
                savedPrev.prev = newChar;


                currentLink = newChar;


            }
        } catch (NullPointerException e) {  //Error catch, not used but for safety
            System.out.println("ERROR!: " + currentLink.toString());
        }
    }

    /**
     * @param s only a charecter or \r
     */
    public int insertUR(String s, boolean wp) {


        if (s.equals("\r")) {


            EditorCharecter newChar = new EditorCharecter("\r", 0);

            EditorCharecter savedPrev = currentLink.next;
            currentLink.next = newChar;


            newChar.prev = currentLink;
            newChar.next = savedPrev;
            savedPrev.prev = newChar;

            currentLink = newChar;

            if (linenum < lineList.size() - 1) {
                lineList.add(linenum + 1, new LinePlaceHolder(currentLink));
            } else {
                lineList.add(new LinePlaceHolder(currentLink));
            }

            linenum++;
            return 1;

        } else {


            EditorCharecter newChar = new EditorCharecter(s, setPixWidth(s));

            EditorCharecter savedPrev = currentLink.next;
            currentLink.next = newChar;


            newChar.prev = currentLink;
            newChar.next = savedPrev;
            savedPrev.prev = newChar;


            currentLink = newChar;
            return newChar.getPixelsize();


        }
    }

    public int backspace() {

        if (currentLink.toString().equals("\r")) {
            int check = getfontHeightExperimental(linenum);
            if (undo.size() <= 100) {
                undo.push(new UndoRedoContainer("backspace", "\r"));
            } else {
                undo.removeLast();
                undo.push(new UndoRedoContainer("backspace", "\r"));
            }
            lineList.remove(linenum - 1);


            currentLink = currentLink.prev;
            currentLink.next = currentLink.next.next;
            currentLink.next.prev = currentLink;
            return -1;
        }  else if (currentLink.isSentinal()) {
            return -10;

        } else if (currentLink.iswrapped()) {
            currentLink = currentLink.prev;
            return -10;

        } else {

            if (undo.size() <= 100) {
                undo.push(new UndoRedoContainer("backspace", currentLink.toString()));
            } else {
                undo.removeLast();
                undo.push(new UndoRedoContainer("backspace", currentLink.toString()));
            }
            int charSize = setPixWidth(currentLink.toString());

            currentLink = currentLink.prev;
            currentLink.next = currentLink.next.next;
            currentLink.next.prev = currentLink;
            return charSize;

        }
    }

    public void decrementLineNum() {
        linenum--;
    }

    private int backspaceUR() {

        if (currentLink.isSentinal()) {
            return 0;

        }
        if (currentLink.toString().equals("\r")) {


            lineList.remove(linenum - 1);
            linenum--;

            currentLink = currentLink.prev;
            currentLink.next = currentLink.next.next;
            currentLink.next.prev = currentLink;
            return -1;

        } else {
            int pix = currentLink.getPixelsize();

            currentLink = currentLink.prev;
            currentLink.next = currentLink.next.next;
            currentLink.next.prev = currentLink;
            return pix;

        }

    }

    /**
     * word wrap occurs here, method works, is fast, but is extreme complicated :(
     * @return String representation (including new lines) of entire text for rendering
     */
    public String toString(int width) {
        ArrayList<LinePlaceHolder> newList = new ArrayList<>();
        removeOldNewLines();
        if (width < 0) {
            width = 0;
        }

        EditorCharecter iterationReady = masterLink;

        String string = ""; // returns blank string if nothing but sentinals
        newList.add(new LinePlaceHolder(iterationReady));

        iterationReady = iterationReady.next;

        int pixSoFar = 0; // for "\r"
        int spacesofar = 0; // index so far from nearest
        int wordpix = 0; //pixels of word

        EditorCharecter wordBegining = null; // start with char after space
        while (iterationReady.next != null && !iterationReady.isSentinal()) {





            if (pixSoFar > width && wordpix < width) {

                String first = string.substring(0, string.length() - spacesofar - 1);
                String predicate = string.substring(string.length() - spacesofar - 1,
                        string.length());

                if (predicate.substring(0, 1).equals(" ")) {
                    string = first + "\r" + predicate.substring(1, predicate.length());
                } else {
                    string = first + "\r" + predicate;
                }
                pixSoFar = wordpix;

                spacesofar = 0;

                EditorCharecter newChar = new EditorCharecter("\r", 0, true);
                EditorCharecter oldNext = wordBegining.next;

                wordBegining.next = newChar;
                newChar.prev = wordBegining;

                newChar.next = oldNext;
                oldNext.prev = newChar;

                newList.add(new LinePlaceHolder(1, newChar, true));



            } else if (pixSoFar > width && wordpix >= width) {

                string = string + "\r";

                spacesofar = 0;
                pixSoFar = 0;
                wordpix = 0;

                EditorCharecter newChar = new EditorCharecter("\r", 0, true);

                EditorCharecter savedPrev = iterationReady.prev;
                savedPrev.next = newChar;
                newChar.prev = savedPrev;

                newChar.next = iterationReady;
                iterationReady.prev = newChar;

                iterationReady = newChar;
                newList.add(new LinePlaceHolder(1, iterationReady, true));

            }
            if (iterationReady.toString().equals("\r") && !iterationReady.iswrapped()) {
                spacesofar = 0;
                wordpix = 0;
                pixSoFar = 0;

                newList.add(new LinePlaceHolder((iterationReady)));
            } else if (iterationReady.toString().equals(" ")) {
                int spacepix = setPixWidth(" ");

                if (spacepix + pixSoFar > width) {
                    int holder = 0;
                } else {
                    wordpix = 0;
                    pixSoFar = pixSoFar + setPixWidth(" ");
                    spacesofar = 0;
                    wordBegining = iterationReady;
                    while (!wordBegining.next.isSentinal()
                            && wordBegining.next.toString().equals(" ")) {
                        wordBegining = wordBegining.next;
                    }
                }

            } else {
                spacesofar++;
                wordpix = wordpix + iterationReady.getPixelsize();
                pixSoFar = pixSoFar + iterationReady.getPixelsize();

            }
            if (!iterationReady.iswrapped()) {
                string = string + iterationReady.toString();
            }

            iterationReady = iterationReady.next;

        }

        lineList = newList;
        return string;

    }



    private void linePrintDebug() {
        System.out.println("\ncursize: " + lineList.size() + "\n\n\n");
        int counter = 0;
        for (LinePlaceHolder i : lineList) {
            System.out.print("line: " + counter + "   ");
            EditorCharecter x = i.getNL().next;
            while (!x.isSentinal() && !x.toString().equals("\r")) {
                System.out.print(x.toString());
                x = x.next;
            }
            System.out.println();
            counter++;

        }
    }

    /**
     * @return String representation (including new lines) of entire text for saving in a file
     * ignores new wrapped lines
     */
    public String toFileString() {

        EditorCharecter iterationReady = masterLink;

        String string = ""; // returns blank string if nothing but sentinals

        iterationReady = iterationReady.next;

        while (iterationReady.next != null && !iterationReady.isSentinal()) {

            if (!iterationReady.iswrapped()) {
                String s = iterationReady.toString();

                //convert \r to \n
                if (s.equals("\r")) {
                    string = string + "\n";
                } else {
                    string = string + s;
                }
            }
            iterationReady = iterationReady.next;
        }

        return string;

    }

    //FIX THIS AND ALL SHALL WORK TODO
    private void removeOldNewLines() {
        EditorCharecter iterationRead = masterLink.next;
        while (iterationRead.next != null && !iterationRead.isSentinal()) {

            if (iterationRead.iswrapped()) {


                iterationRead = iterationRead.prev;
                iterationRead.next = iterationRead.next.next;
                iterationRead.next.prev = iterationRead;


            } else {
                iterationRead = iterationRead.next;
            }
        }

        for (int i = 0; i < lineList.size(); i++) {

            LinePlaceHolder x = lineList.get(i);

            if (x.isWordWrap()) {
                lineList.remove(i);

                while (i < lineList.size() && lineList.get(i).isWordWrap()) {
                    lineList.remove(i);
                }
            }


        }
    }

    public int getLinenum() {
        return linenum - 1;
    }

    public int getfontHeightExperimental(int i) {

        if (i == 0) {
            return 0;
        }
        String str = "i";
        String nl = "\ri";
        while (i > 1) {
            str  = str + nl;
            i--;
        }
        //calc new pixel size
        final Text text = new Text(str);
        text.setTextOrigin(VPos.TOP);
        text.setFont(Font.font(fonttype, fontsize));

        return (int) Math.round(text.getLayoutBounds().getHeight());
    }


    public int getPixSideways() {
        EditorCharecter x = lineList.get(Math.max(0, linenum - 1)).getNL();
        String str = "";

        if (x.isSentinal()) {
            x = x.next;
        }

        while (!(x == currentLink.next) && !x.isSentinal()) {
            str = str + x.toString();
            x = x.next;

        }

        //calc new pixel size
        Text text = new Text(str);
        text.setTextOrigin(VPos.TOP);
        text.setFont(Font.font(fonttype, fontsize));



        return (int) Math.round(text.getLayoutBounds().getWidth());
    }
    public int getFontHeight() {
        return fontHeight;
    }

    public int setPixWidth(String s) {


        //calc new pixel size
        final Text text = new Text(s);
        text.setTextOrigin(VPos.TOP);
        text.setFont(Font.font(fonttype, fontsize));

        final Text textHeight = new Text("i");
        textHeight.setTextOrigin(VPos.TOP);
        textHeight.setFont(Font.font(fonttype, fontsize));
        fontHeight = (int) Math.round(textHeight.getLayoutBounds().getHeight());


        return (int) Math.round(text.getLayoutBounds().getWidth());

    }



    /**
     * arrow key left
     */
    public int moveLeft() {
        if (!currentLink.isSentinal()) {
            if (currentLink.toString().equals("\r") && getPixSideways() == 0) {
                linenum = linenum - 1;
            }
            currentLink = currentLink.prev;
        }
        return 0;
    }

    /**
     * arrow key right
     */
    public int moveRight() {
        if (!currentLink.next.isSentinal()) {
            currentLink = currentLink.next;

            if (currentLink.toString().equals("\r")) {
                linenum = linenum + 1;
            }
        }
        return 0;
    }

    /**
     * @return 1 for new line, -1 for del line, pix size pix moved left
     */
    public int undo() {
        UndoRedoContainer x;
        try {
            x = undo.pop();
        } catch (NoSuchElementException e) {
            return 0;
        }
        if (x.getActionType().equals("backspace")) {

            redo.push(x);
            return insertUR(x.getCharecter(), false);
        } else if (x.getActionType().equals("insert")) {
            redo.push(x);
            return backspaceUR();
        }


        return 0;

    }

    public int redo() {
        if (redo.size() == 0) {
            return 0;
        }
        UndoRedoContainer x = redo.pop();

        if (x.getActionType().equals("backspace")) {
            return backspaceUR();
        } else {
            return insertUR(x.getCharecter(), false);
        }

    }

}
