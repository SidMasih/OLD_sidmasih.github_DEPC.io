package editor;


import java.io.File;
import java.io.PrintWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileWriter;
/**
 * Created by sidmasih on 2/27/16.
 */
public class EditorIO {
    private static String fname;
    public static String readFileToString(String filename) {
        fname = filename;
        try {
            File inputFile = new File(filename);
            // Check to make sure that the input file exists!
            if (!inputFile.exists()) {
                PrintWriter newfile = new PrintWriter(filename, "ASCII");
                newfile.close();
                return null;
            }
            FileReader reader = new FileReader(inputFile);
            BufferedReader bufferedReader = new BufferedReader(reader);


            int intRead;
            String string = "";
            // Keep reading from the file input read() returns -1, which means the end of the file
            // was reached.
            while ((intRead = bufferedReader.read()) != -1) {
                // The integer read can be cast to a char, because we're assuming ASCII.
                char charRead = (char) intRead;
                if (charRead == '\r') {
                    //skip the \n
                    bufferedReader.read();
                } else if (charRead == '\n') {
                    char nl = '\r';
                    string = string + String.valueOf(nl);
                } else {
                    string = string + String.valueOf(charRead);
                }
            }

            bufferedReader.close();
            return string;

            // Close the reader and writer.

        } catch (FileNotFoundException fileNotFoundException) {
            System.out.println("File not found! Exception was: " + fileNotFoundException);
            System.exit(1);
        } catch (IOException ioException) {
            System.out.println("Error when copying; exception was: " + ioException);
            System.exit(1);
        }
        return null;
    }


    public static void saveToFile(String s) {
        try {

            FileWriter writer = new FileWriter(fname);

            char [] toFileCharArray = s.toCharArray();

            for (char c : toFileCharArray) {
                writer.write(c);
            }

            writer.close();
        } catch (FileNotFoundException fileNotFoundException) {
            System.out.println("File not found! Exception was: " + fileNotFoundException);
            System.exit(1);
        } catch (IOException ioException) {
            System.out.println("Error when copying; exception was: " + ioException);
            System.exit(1);
        }
    }

}
