package editor;

/**
 * Created by sidmasih on 2/26/16.
 * debugging printer class
 */
public class DebugPrint {

    private static boolean debugAllowed = false;
    private static int messagenum = 1;

    public DebugPrint(boolean choice) {
        debugAllowed = choice;
    }

    public DebugPrint() {
        // do nothing
    }

    public void print(String toPrint) {

        if (debugAllowed) {
            System.out.println("M#: " + messagenum + " mes: " + toPrint);
            messagenum++;
        }
    }

    /**
     *  String only
     * @param x String []
     */
    public void printArray1D(String [] x) {
        System.out.println("M#: " + messagenum + "printing array\n");
        for (Object i : x) {
            System.out.println(i);
        }
        messagenum++;
        System.out.println("array done \n");
    }




}
