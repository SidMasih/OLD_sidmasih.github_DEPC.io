package editor;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ScrollBar;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * This project legit made me cry :( Not ashamed to say it
 * (Thank you Berkeley Computer Science for making me cry for the first time in years)
 * A JavaFX application that displays the letter the user has typed most recently in the center of
 * the window. Pressing the up and down arrows causes the font size to increase and decrease,
 * respectively.
 */
public class Editor extends Application {
    private static DebugPrint debugPrinter;

    private static CoreDataControl coreData;
    private Rectangle textBoundingBox;
    private int linenum;





    String myText = "";
    private static int WINDOW_WIDTH = 500;
    private static int WINDOW_HEIGHT = 500;
    private static final int MARGIN = 25;
    private int scrollCorrection = -0;
    int textX;
    int textY;


    private ScrollBar scrollBar;


    private static final int STARTING_FONT_SIZE = 12;
    private static final int STARTING_TEXT_POSITION_X = 5;
    private static final int STARTING_TEXT_POSITION_Y = 0;

    /** The Text to display on the screen. */
    private Text displayText = new Text(STARTING_TEXT_POSITION_X, STARTING_TEXT_POSITION_Y, "");
    private int fontSize = STARTING_FONT_SIZE;

    private String fontName = "Verdana";

    public Editor() {
        this.textBoundingBox = new Rectangle(1, 15);

    }


    private int calcLineNumber(int pixMouse) {

        return (int) (Math.round((pixMouse)
                + Math.abs(scrollCorrection)) / coreData.getFontHeight());

    }




    private int getDimensionInsideMargin(int outsideDimension) {
        return outsideDimension - 2 * MARGIN;
    }
    /** An EventHandler to handle keys that get pressed. */
    /** An event handler that displays the current position of the mouse whenever it is clicked. */
    private class MouseClickEventHandler implements EventHandler<MouseEvent> {
        /** A Text object that will be used to print the current mouse position. */
        Text positionText;

        MouseClickEventHandler(Group root) {
            // For now, since there's no mouse position yet, just create an empty Text object.
            positionText = new Text("");
            // We want the text to show up immediately above the position, so set the origin to be
            // VPos.BOTTOM (so the x-position we assign will be the position of the bottom of the
            // text).
            positionText.setTextOrigin(VPos.BOTTOM);

            // Add the positionText to root, so that it will be displayed on the screen.
            root.getChildren().add(positionText);

        }


        @Override
        public void handle(MouseEvent mouseEvent) {
            // Because we registered this EventHandler using setOnMouseClicked, it will only called
            // with mouse events of type MouseEvent.MOUSE_CLICKED.  A mouse clicked event is
            // generated anytime the mouse is pressed and released on the same JavaFX node.
            double mousePressedX = mouseEvent.getX();
            double mousePressedY = mouseEvent.getY();
            linenum = calcLineNumber((int) Math.round(mousePressedY));

            if (linenum > coreData.calcMaxLineNumber()) {
                linenum = coreData.calcMaxLineNumber() - 1;
            }

            coreData.cursorLocationMove(linenum, ((int) Math.round(mousePressedX) - 20));
            textY = coreData.getfontHeightExperimental(linenum);
            textX = coreData.getPixSideways();

            moveBlinkingCursor();

        }
    }

    private class KeyEventHandler implements EventHandler<KeyEvent> {


        KeyEventHandler(final Group root, int windowWidth, int windowHeight) {
            textX = 5;
            textY = 0;

            // Initialize some empty text and add it to root so that it will be displayed.
            coreData.setFontsize(12);

            displayText = new Text(textX, textY,
                    coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH)));

            // Always set the text origin to be VPos.TOP! Setting the origin to be VPos.TOP means
            // that when the text is assigned a y-position, that position corresponds to the
            // highest position across all letters (for example, the top of a letter like "I", as
            // opposed to the top of a letter like "e"), which makes calculating positions much
            // simpler!
            displayText.setTextOrigin(VPos.TOP);
            displayText.setFont(Font.font(fontName, fontSize));
            root.getChildren().add(textBoundingBox);

            // All new Nodes need to be added to the root in order to be displayed.
            root.getChildren().add(displayText);
            moveBlinkingCursor();
        }

        @Override
        public void handle(KeyEvent keyEvent) {
            int numOldLines = coreData.calcMaxLineNumber();
            int oldFont = coreData.getFontHeight();

            if (keyEvent.getEventType() == KeyEvent.KEY_TYPED) {
                // Use the KEY_TYPED event rather than KEY_PRESSED for letter keys, because with
                // the KEY_TYPED event, javafx handles the "Shift" key and associated
                // capitalization.
                String characterTyped = keyEvent.getCharacter();
                if (characterTyped.length() > 0 && characterTyped.charAt(0)
                        != 8 && !keyEvent.isShortcutDown()) {
                    // Ignore control keys, which have non-zero length, as well as the backspace
                    // key, which is represented as a character of value = 8 on Windows.

                    if (characterTyped.equals("\r")) {
                        coreData.insert(characterTyped, false);
                        linenum++;
                        textX = 0;
                        textY = coreData.getfontHeightExperimental(coreData.getLinenum());
                        moveBlinkingCursor();

                    } else {
                        coreData.insert(characterTyped, false);
                    }

                    displayText.setText(coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH)));
                    keyEvent.consume();

                } else if (characterTyped.length() > 0 && characterTyped.charAt(0)
                        != 8 && keyEvent.isShortcutDown()) {

                    if (characterTyped.equals("s")) {
                        EditorIO.saveToFile(coreData.toFileString());
                    } else if (characterTyped.equals("=")) {

                        fontSize = Math.max(fontSize, 2 + fontSize);
                        coreData.setFontsize(fontSize);

                        displayText.setFont(Font.font(fontName, fontSize));
                        myText = coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH));
                        displayText.setText(myText);
                        textBoundingBox.setHeight(coreData.getFontHeight());

                    } else if (characterTyped.equals("-")) {

                        fontSize = Math.max(5, fontSize - 2);
                        coreData.setFontsize(fontSize);
                        displayText.setFont(Font.font(fontName, fontSize));
                        myText = coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH));
                        displayText.setText(myText);
                        textBoundingBox.setHeight(coreData.getFontHeight());

                    } else if (characterTyped.equals("p")) {
                        System.out.println((textX + 5) + "," + (textY + 0));
                    } else if (characterTyped.equals("z")) {
                        coreData.undo();
                        displayText.setText(coreData.toString(
                                getDimensionInsideMargin(WINDOW_WIDTH)));

                    } else if (characterTyped.equals("y")) {
                        coreData.redo();
                        displayText.setText(coreData.toString(
                                getDimensionInsideMargin(WINDOW_WIDTH)));

                    }
                }


            } else if (keyEvent.getEventType() == KeyEvent.KEY_PRESSED) {

                KeyCode code = keyEvent.getCode();
                if (code == KeyCode.BACK_SPACE) {
                    int numLines = coreData.calcMaxLineNumber();
                    coreData.backspace();
                    myText = coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH));
                    displayText.setText(myText);
                    if (coreData.calcMaxLineNumber() < numLines) {
                        coreData.decrementLineNum();
                    }

                } else if (code == KeyCode.LEFT) {
                    coreData.moveLeft();

                } else if (code == KeyCode.RIGHT) {
                    coreData.moveRight();
                } else if (code == KeyCode.UP) {
                    coreData.cursorLocationMove(coreData.getLinenum() - 1,
                            coreData.getPixSideways());
                } else if (code == KeyCode.DOWN) {
                    textX = coreData.getPixSideways();
                    int line = coreData.getLinenum() + 1;

                    coreData.cursorLocationMove(line, textX);
                }
            }

            int dif =  (coreData.calcMaxLineNumber() + 1) * coreData.getFontHeight();

            if (dif - WINDOW_HEIGHT > 0) {
                scrollBar.setMax(dif);
            } else {
                scrollBar.setMax(0);
            }


            int newNumLines = coreData.calcMaxLineNumber();
            if (coreData.getLinenum() > numOldLines) {
                int delta = (numOldLines + 1) * oldFont
                        - (newNumLines + 1) * coreData.getFontHeight();
                scrollBar.setValue(scrollBar.getValue() + delta);
                scrollCorrection = scrollCorrection + delta;
            }


            textX = coreData.getPixSideways();
            textY = coreData.getfontHeightExperimental(coreData.getLinenum());
            moveBlinkingCursor();
        }

    }
    /** Makes the text bounding box blink. */
    public void makeRectangleColorChange() {

        final Timeline timeline = new Timeline();
        // The rectangle should continue blinking forever.
        timeline.setCycleCount(Timeline.INDEFINITE);
        RectangleBlinkEventHandler cursorChange = new RectangleBlinkEventHandler();
        KeyFrame keyFrame = new KeyFrame(Duration.seconds(.5), cursorChange);
        timeline.getKeyFrames().add(keyFrame);
        timeline.play();
    }

    private void moveBlinkingCursor() {
        textBoundingBox.setX(textX + 5);
        textBoundingBox.setY(textY + 0);
    }
    @Override
    public void start(Stage primaryStage) {
        // Create a Node that will be the parent of all things displayed on the screen.
        Group root = new Group();
        Group textRoot = new Group();
        root.getChildren().add(textRoot);
        // The Scene represents the window: its height and width will be the height and width
        // of the window displayed.
        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT, Color.WHITE);

        // To get information about what keys the user is pressing, create an EventHandler.
        // EventHandler subclasses must override the "handle" function, which will be called
        // by javafx.
        EventHandler<KeyEvent> keyEventHandler =
                new KeyEventHandler(textRoot, WINDOW_WIDTH, WINDOW_HEIGHT);
        // Register the event handler to be called for all KEY_PRESSED and KEY_TYPED events.
        scene.setOnKeyTyped(keyEventHandler);
        scene.setOnKeyPressed(keyEventHandler);
        scene.setOnMouseClicked(new MouseClickEventHandler(root));


        // Make a vertical scroll bar on the right side of the screen.
        scrollBar = new ScrollBar();
        scrollBar.setOrientation(Orientation.VERTICAL);
        // Set the height of the scroll bar so that it fills the whole window.
        scrollBar.setPrefHeight(WINDOW_HEIGHT);

        // Set the range of the scroll bar.
        scrollBar.setMin(0);
        coreData.toString(WINDOW_HEIGHT);
        int dif =  (coreData.calcMaxLineNumber() + 1) * coreData.getFontHeight();


        if (dif - WINDOW_HEIGHT > 0) {
            scrollBar.setMax(dif);
        } else {
            scrollBar.setMax(0);
        }

        // Add the scroll bar to the scene graph, so that it appears on the screen.
        root.getChildren().add(scrollBar);
        scene.widthProperty().addListener(new ChangeListener<Number>() {
            @Override public void changed(
                    ObservableValue<? extends Number> observableValue,
                    Number oldScreenWidth,
                    Number newScreenWidth) {
                WINDOW_WIDTH = newScreenWidth.intValue();
                scrollBar.setLayoutX(newScreenWidth.doubleValue()
                        - scrollBar.getLayoutBounds().getWidth());
                displayText.setText(coreData.toString(getDimensionInsideMargin(WINDOW_WIDTH)));

                int dif =  (coreData.calcMaxLineNumber() + 1) * coreData.getFontHeight();

                if (dif - WINDOW_HEIGHT > 0) {
                    scrollBar.setMax(dif);
                } else {
                    scrollBar.setMax(0);
                }


            }
        });
        scene.heightProperty().addListener(new ChangeListener<Number>() {
            @Override public void changed(
                    ObservableValue<? extends Number> observableValue,
                    Number oldScreenHeight,
                    Number newScreenHeight) {
                WINDOW_HEIGHT = newScreenHeight.intValue();
               // int newHeight = newScreenHeight.intValue();
                scrollBar.setPrefHeight(WINDOW_HEIGHT);
                coreData.toString(WINDOW_WIDTH);
                int dif =  (coreData.calcMaxLineNumber() + 1) * coreData.getFontHeight();

                if (dif - WINDOW_HEIGHT > 0) {
                    scrollBar.setMax(dif);
                } else {
                    scrollBar.setMax(0);
                }
            }
        });

        double usableScreenWidth = WINDOW_WIDTH - scrollBar.getLayoutBounds().getWidth();
        scrollBar.setLayoutX(usableScreenWidth);

        scrollBar.valueProperty().addListener(new ChangeListener<Number>() {
            public void changed(
                    ObservableValue<? extends Number> observableValue,
                    Number oldValue,
                    Number newValue) {
                // newValue describes the value of the new position of the scroll bar. The numerical
                // value of the position is based on the position of the scroll bar, and on the min
                // and max we set above. For example, if the scroll bar is exactly in the middle of
                // the scroll area, the position will be:
                //      scroll minimum + (scroll maximum - scroll minimum) / 2
                // Here, we can directly use the value of the scroll bar to set the height of Josh,
                // because of how we set the minimum and maximum above.
                int delta = oldValue.intValue() - newValue.intValue();
                scrollCorrection = scrollCorrection + delta;
                textRoot.setLayoutY(scrollCorrection);

            }
        });
        makeRectangleColorChange();
        primaryStage.setTitle("CS61b Big Project Editor");

        // This is boilerplate, necessary to setup the window where things are displayed.
        primaryStage.setScene(scene);
        primaryStage.show();

        // insert startup cursor
        coreData.cursorLocationMove(0, 0);
        coreData.insert("t", false);
        coreData.backspace();
        textY = 0;
        textX = coreData.getPixSideways();
        moveBlinkingCursor();
    }
    /** An EventHandler to handle changing the color of the rectangle. */
    private class RectangleBlinkEventHandler implements EventHandler<ActionEvent> {
        private int currentColorIndex = 0;
        private Color[] boxColors = {Color.BLACK, Color.WHITE};

        RectangleBlinkEventHandler() {
            // Set the color to be the first color in the list.
            changeColor();
        }

        private void changeColor() {
            textBoundingBox.setFill(boxColors[currentColorIndex]);
            currentColorIndex = (currentColorIndex + 1) % boxColors.length;
        }

        @Override
        public void handle(ActionEvent event) {
            changeColor();
        }
    }
    public static void main(String[] args) {

        if (args.length == 0) {
            System.out.println("Error: you must provide a file name");
            return;
        }

        // debugging on or off?
        if (args.length == 2 && args[1].equals("debug")) {
            debugPrinter = new DebugPrint(true);
        } else {
            debugPrinter = new DebugPrint(false);
        }

        coreData = new CoreDataControl();

        //read data into file
        String data = EditorIO.readFileToString(args[0]);

        if (data != null) {
            coreData.insertLargeString(data, false);
        }

        launch(args);
    }
}
