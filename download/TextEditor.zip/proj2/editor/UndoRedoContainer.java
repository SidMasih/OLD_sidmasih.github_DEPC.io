package editor;

/**
 * Created by sidmasih on 2/28/16.
 */
public class UndoRedoContainer {

    private String actionType;

    private String charecter;

    public String getActionType() {
        return actionType;
    }

    public String getCharecter() {
        return charecter;
    }

    public UndoRedoContainer(String actionType, String charecter) {

        this.actionType = actionType;
        this.charecter = charecter;
    }
}
