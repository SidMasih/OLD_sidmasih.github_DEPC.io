import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

/**
 * Created by sidmasih on 4/11/16.
 */
public class QuadTree {
    // make class that loads all the file names into the correct nodes
    // just need a get function NO DELETE
    // balanced so log n time
    //

    int nnncch = 0;
    private TileIntersect theWindow;

    private QuadTreeNode root;
    private HashSet<QuadTreeNode> tileHolder; //must wipe
    public static final double ROOT_ULLAT = 37.892195547244356, ROOT_ULLON = -122.2998046875,
            ROOT_LRLAT = 37.82280243352756, ROOT_LRLON = -122.2119140625;


    public QuadTree() {

        Object [] s = {null, null, null, null};
        root = new QuadTreeNode("root", s,
                ROOT_ULLAT, ROOT_ULLON, ROOT_LRLAT, ROOT_LRLON, 0);

        double nlat = (ROOT_LRLAT + ROOT_ULLAT) / 2;
        double nlon = (ROOT_ULLON + ROOT_LRLON) / 2;

        root.setUl(generateNodes(1, ROOT_ULLAT, ROOT_ULLON, nlat, nlon, 1));
        root.setUr(generateNodes(2, ROOT_ULLAT, nlon, nlat, ROOT_LRLON, 1));
        root.setLl(generateNodes(3, nlat, ROOT_ULLON, ROOT_LRLAT, nlon, 1));
        root.setLr(generateNodes(4, nlat, nlon, ROOT_LRLAT, ROOT_LRLON, 1));

    }

    private QuadTreeNode generateNodes(int id, double ullat, double ullon,
                                       double lrlat, double lrlon, int level) {
        Object [] s = {null, null, null, null};

        if (Integer.toString(id).length() == 7) {
            return new QuadTreeNode(Integer.toString(id), s,
                    ullat, ullon, lrlat, lrlon, level);
        }


        QuadTreeNode x = new QuadTreeNode(Integer.toString(id), s,
                ullat, ullon, lrlat, lrlon, level);

        double nlat = (lrlat + ullat) / 2;
        double nlon = (ullon + lrlon) / 2;
        int newLevel = level + 1;

        x.setUl(generateNodes(id * 10 + 1, ullat, ullon, nlat, nlon, newLevel));
        x.setUr(generateNodes(id * 10 + 2, ullat, nlon, nlat, lrlon, newLevel));
        x.setLl(generateNodes(id * 10 + 3, nlat, ullon, lrlat, nlon, newLevel));
        x.setLr(generateNodes(id * 10 + 4, nlat, nlon, lrlat, lrlon, newLevel));

        return x;
    }

    /**
     * @param dppDesired
     * @param ullat
     * @param ullon
     * @param lrlat
     * @param lrlon
     * @return iterator of all the tiles
     */
    private Iterator<QuadTreeNode> getTilesForRaster(double dppDesired, double ullat, double ullon,
                                                     double lrlat, double lrlon) {

        theWindow = new TileIntersect(ullon, ullat, lrlon, lrlat);
        tileHolder = new HashSet<>();

        hashAdderHelper(root, dppDesired, ullat, ullon, lrlat, lrlon);


        return tileHolder.iterator();


    }

    private void hashAdderHelper(QuadTreeNode n, double dppDesired, double ullat, double ullon,
                                 double lrlat, double lrlon) {

        //reached the bottom
        if (n.getUl() == null || n.getUr() == null || n.getLr() == null || n.getLl() == null) {

            if (n.isInUserBox(ullat, ullon, lrlat, lrlon)) {
                tileHolder.add(n);

                return;
            } else {
                return; // stop
            }
        }


        //not at total bottom but right depth
        if (n.getDpp() <= dppDesired) {
            if (n.isInUserBox(ullat, ullon, lrlat, lrlon) || theWindow.compare(n.tile)) {
                tileHolder.add(n);
                nnncch++;
                return;
            } else {
                return; //reached right depth but not in box so reject
            }
        }


        //still need to go down
        if (n.getUl().isInUserBox(ullat, ullon, lrlat, lrlon)) {
            hashAdderHelper(n.getUl(), dppDesired, ullat, ullon, lrlat, lrlon);
        }
        if (n.getUr().isInUserBox(ullat, ullon, lrlat, lrlon)) {
            hashAdderHelper(n.getUr(), dppDesired, ullat, ullon, lrlat, lrlon);
        }
        if (n.getLl().isInUserBox(ullat, ullon, lrlat, lrlon)) {
            hashAdderHelper(n.getLl(), dppDesired, ullat, ullon, lrlat, lrlon);
        }
        if (n.getLr().isInUserBox(ullat, ullon, lrlat, lrlon)) {
            hashAdderHelper(n.getLr(), dppDesired, ullat, ullon, lrlat, lrlon);
        }

    }

    public void testgetTilesForRaster(double dppDesired, double ullat, double ullon,
                                      double lrlat, double lrlon) {

        Iterator<QuadTreeNode> x = getTilesForRaster(dppDesired, ullat, ullon, lrlat, lrlon);

        while (x.hasNext()) {
            System.out.println(x.next().toFileString());
        }
    }

    private ArrayList<NodeLatHolder> getRaster(Iterator<QuadTreeNode> iter) {


        ArrayList<NodeLatHolder> listOfNodes = new ArrayList<>();

        ArrayList<QuadTreeNode> unsortedNodes = new ArrayList<>();
        HashSet<Double> set = new HashSet<>();


        while (iter.hasNext()) {
            QuadTreeNode theNode = iter.next();

            unsortedNodes.add(theNode);
            set.add(theNode.getUllat());
        }


        Iterator<Double> setIter = set.iterator();

        while (setIter.hasNext()) {
            double disLat = setIter.next();

            listOfNodes.add(new NodeLatHolder(disLat));
        }

        Collections.sort(listOfNodes); // lats in order


        for (QuadTreeNode qn : unsortedNodes) {

            for (int i = 0; i < listOfNodes.size(); i++) {

                if (listOfNodes.get(i).equals(qn.getUllat())) {
                    listOfNodes.get(i).addElement(qn);

                }
            }

        }

        return listOfNodes;
    }

    public ArrayList<NodeLatHolder> returnTilesFor(double dppDesired, double ullat, double ullon,
                                                   double lrlat, double lrlon) {

        return getRaster(getTilesForRaster(dppDesired, ullat, ullon, lrlat, lrlon));

    }


    public QuadTreeNode getRoot() {
        return root;
    }
}
