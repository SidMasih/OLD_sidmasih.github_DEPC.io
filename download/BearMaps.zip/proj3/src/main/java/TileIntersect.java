/**
 * Created by sidmasih on 4/13/16.
 * theory was created with friend
 */
public class TileIntersect {

    private double x1, y1, x2, y2, x3, y3, x4, y4;


    public TileIntersect(double xa, double ya, double xb, double yb) {
        this.x1 = xa;
        this.y1 = ya;

        this.x2 = xb;
        this.y2 = yb;

        this.x3 = xb;
        this.y3 = ya;

        this.x4 = xa;
        this.y4 = yb;
    }


    public boolean compare(TileIntersect t) {


        // this one caused a really hard to find bug ... (ie 6 hours)
        boolean a = this.x1 <= t.x1 && this.y1 <= t.y1 && this.x2 >= t.x2 && this.y2 >= t.y2;

        boolean b = (t.x3 >= this.x1 && t.x3 <= this.x2) && (t.y3 <= this.y1 && t.y3 >= this.y2);
        boolean c = (t.x2 >= this.x1 && t.x2 <= this.x2) && (t.y2 <= this.y1 && t.y2 >= this.y2);

        boolean d = (t.x4 >= this.x1 && t.x4 <= this.x2) && (t.y4 <= this.y1 && t.y4 >= this.y2);
        boolean e = (t.x1 >= this.x1 && t.x1 <= this.x2) && (t.y1 <= this.y1 && t.y1 >= this.y2);


        return (a || b || c || d || e);
    }


}
