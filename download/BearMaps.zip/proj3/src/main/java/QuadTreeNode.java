/**
 * Created by sidmasih on 4/11/16.
 */
public class QuadTreeNode implements Comparable<QuadTreeNode> {

    private String filename;
    private QuadTreeNode ul;
    private QuadTreeNode ur;
    private QuadTreeNode ll;
    private QuadTreeNode lr;
    private double ullong;
    private double ullat;
    private double lrlong;
    private double lrlat;

    private int level;
    private double dpp;
    private static final double DOUBLETHRESHOLD = 0.0000000000001;

    public String getFilename() {
        return filename;
    }

    TileIntersect tile;


    public QuadTreeNode getUl() {
        return ul;
    }

    public QuadTreeNode getUr() {
        return ur;
    }

    @Override
    public String toString() {
        return "QuadTreeNode{"
                + "filename='" + filename + '\''
                + ", ul=" + ul
                + ", ur=" + ur
                + ", ll=" + ll
                + ", lr=" + lr
                + '}';
    }

    public String toStringShort() {
        return "QuadTreeNode{"
                + "filename='" + filename + '\''
                + '}';
    }

    public String toFileString() {
        return "img/" + filename + ".png";
    }


    public QuadTreeNode getLl() {
        return ll;

    }

    public QuadTreeNode getLr() {
        return lr;
    }

    public double getUllong() {
        return ullong;
    }

    public double getUllat() {
        return ullat;
    }

    public double getLrlong() {
        return lrlong;
    }

    public double getLrlat() {
        return lrlat;
    }

    public int getLevel() {
        return level;
    }

    public QuadTreeNode(String filename, Object [] lats, double ulat, double ulong,
                        double lrat, double llong, int level) {


        this.ullong = ulong;
        this.ullat = ulat;
        this.lrlong = llong;
        this.lrlat = lrat;

        this.level = level;


        this.filename = filename;
        this.ul = (QuadTreeNode) lats[0];
        this.ur = (QuadTreeNode) lats[1];
        this.ll = (QuadTreeNode) lats[2];
        this.lr = (QuadTreeNode) lats[3];

        dpp = Math.abs((QuadTree.ROOT_LRLON - QuadTree.ROOT_ULLON) / (256 * Math.pow(2, level)));

        tile = new TileIntersect(ulong, ulat, llong, lrat);


    }

    public boolean isInUserBox(double ulat, double ulong, double lrat, double llong) {


        return tile.compare(new TileIntersect(ulong, ulat, llong, lrat))
                || new TileIntersect(ulong, ulat, llong, lrat).compare(tile);


    }

    public boolean isInUserBox(double ulat, double ulong,
                               double lrat, double llong, boolean check) {

        return tile.compare(new TileIntersect(ulong, ulat, llong, lrat));


    }

    /**
     * Compares this object with the specified object for order.  Returns a
     * negative integer, zero, or a positive integer as this object is less
     * than, equal to, or greater than the specified object.
     * <p>
     * <p>The implementor must ensure <tt>sgn(x.compareTo(y)) ==
     * -sgn(y.compareTo(x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
     * implies that <tt>x.compareTo(y)</tt> must throw an exception iff
     * <tt>y.compareTo(x)</tt> throws an exception.)
     * <p>
     * <p>The implementor must also ensure that the relation is transitive:
     * <tt>(x.compareTo(y)&gt;0 &amp;&amp; y.compareTo(z)&gt;0)</tt> implies
     * <tt>x.compareTo(z)&gt;0</tt>.
     * <p>
     * <p>Finally, the implementor must ensure that <tt>x.compareTo(y)==0</tt>
     * implies that <tt>sgn(x.compareTo(z)) == sgn(y.compareTo(z))</tt>, for
     * all <tt>z</tt>.
     * <p>
     * <p>It is strongly recommended, but <i>not</i> strictly required that
     * <tt>(x.compareTo(y)==0) == (x.equals(y))</tt>.  Generally speaking, any
     * class that implements the <tt>Comparable</tt> interface and violates
     * this condition should clearly indicate this fact.  The recommended
     * language is "Note: this class has a natural ordering that is
     * inconsistent with equals."
     * <p>
     * <p>In the foregoing description, the notation
     * <tt>sgn(</tt><i>expression</i><tt>)</tt> designates the mathematical
     * <i>signum</i> function, which is defined to return one of <tt>-1</tt>,
     * <tt>0</tt>, or <tt>1</tt> according to whether the value of
     * <i>expression</i> is negative, zero or positive.
     *
     * @param o the object to be compared.
     * @return a negative integer, zero, or a positive integer as this object
     * is less than, equal to, or greater than the specified object.
     * @throws NullPointerException if the specified object is null
     * @throws ClassCastException   if the specified object's type prevents it
     *                              from being compared to this object.
     *                              checks using ULong
     */
    @Override
    public int compareTo(QuadTreeNode o) {

        if (Math.abs(this.ullong - o.ullong) <= DOUBLETHRESHOLD) {
            return 0;
        } else if (this.ullong < o.ullong) {
            return -1;
        } else {
            return 1;
        }
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public void setUl(QuadTreeNode ul) {
        this.ul = ul;
    }

    public void setUr(QuadTreeNode ur) {
        this.ur = ur;
    }

    public void setLl(QuadTreeNode ll) {
        this.ll = ll;
    }

    public void setLr(QuadTreeNode lr) {
        this.lr = lr;
    }

    public void setUllong(double ullong) {
        this.ullong = ullong;
    }

    public void setUllat(double ullat) {
        this.ullat = ullat;
    }

    public void setLrlong(double lrlong) {
        this.lrlong = lrlong;
    }

    public void setLrlat(double lrlat) {
        this.lrlat = lrlat;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public double getDpp() {
        return dpp;
    }

    public void setDpp(double dpp) {
        this.dpp = dpp;
    }

    // do recursive approach to constructing images :)
}
