import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * Created by sidmasih on 4/14/16.
 */
public class GetFile {

    public static BufferedImage getFile(String fname) {

        try {

            return ImageIO.read(new File(fname));

        } catch (IOException e) {

            e.printStackTrace();
        }
        return null;
    }

    public static void writeToFileTest(BufferedImage x) {
        try {

            ImageIO.write(x, "png", new File("result.png"));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
