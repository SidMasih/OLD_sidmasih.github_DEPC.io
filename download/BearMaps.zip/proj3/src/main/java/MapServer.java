
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.LinkedList;
import java.util.List;
import javax.imageio.ImageIO;
import java.util.Base64;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.awt.Graphics2D;


/* Maven is used to pull in these dependencies. */
import com.google.gson.Gson;

import static spark.Spark.*;

/**
 * This MapServer class is the entry point for running the JavaSpark web server for the BearMaps
 * application project, receiving API calls, handling the API call processing, and generating
 * requested images and routes.
 *
 * @author Alan Yao
 */
public class MapServer {
    public static final double ROOT_ULLAT = 37.892195547244356, ROOT_ULLON = -122.2998046875,
        ROOT_LRLAT = 37.82280243352756, ROOT_LRLON = -122.2119140625;

    public static final int TILE_SIZE = 256;
    private static final int HALT_RESPONSE = 403;
    public static final float ROUTE_STROKE_WIDTH_PX = 5.0f;
    public static final Color ROUTE_STROKE_COLOR = new Color(108, 181, 230, 200);
    private static final String IMG_ROOT = "img/";
    private static LinkedList<Long> goodPath = new LinkedList<>();
    private static final String OSM_DB_PATH = "berkeley.osm";

    private static final String[] REQUIRED_RASTER_REQUEST_PARAMS = {"ullat", "ullon", "lrlat",
        "lrlon", "w", "h"};

    private static final String[] REQUIRED_ROUTE_REQUEST_PARAMS = {"start_lat", "start_lon",
        "end_lat", "end_lon"};
    private static GraphDB g;


    public static void initialize() {
        g = new GraphDB(OSM_DB_PATH);

    }

    public static void main(String[] args) {
        initialize();
        staticFileLocation("/page");
        /* Allow for all origin requests (since this is not an authenticated server, we do not
         * care about CSRF).  */
        before((request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Request-Method", "*");
            response.header("Access-Control-Allow-Headers", "*");
        });

        /* Define the raster endpoint for HTTP GET requests. I use anonymous functions to define
         * the request handlers. */
        get("/raster", (req, res) -> {
            HashMap<String, Double> params =
                    getRequestParams(req, REQUIRED_RASTER_REQUEST_PARAMS);
            /* The png image is written to the ByteArrayOutputStream */
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            /* getMapRaster() does almost all the work for this API call */
            Map<String, Object> rasteredImgParams = getMapRaster(params, os);
            /* On an image query success, add the image data to the response */
            if (rasteredImgParams.containsKey("query_success")
                    && (Boolean) rasteredImgParams.get("query_success")) {
                String encodedImage = Base64.getEncoder().encodeToString(os.toByteArray());
                rasteredImgParams.put("b64_encoded_image_data", encodedImage);
            }
            /* Encode response to Json */
            Gson gson = new Gson();
            return gson.toJson(rasteredImgParams);
        });

        /* Define the routing endpoint for HTTP GET requests. */
        get("/route", (req, res) -> {
            HashMap<String, Double> params =
                    getRequestParams(req, REQUIRED_ROUTE_REQUEST_PARAMS);
            LinkedList<Long> route = findAndSetRoute(params);
            return !route.isEmpty();
        });

        /* Define the API endpoint for clearing the current route. */
        get("/clear_route", (req, res) -> {
            clearRoute();
            return true;
        });

        /* Define the API endpoint for search */
        get("/search", (req, res) -> {
            Set<String> reqParams = req.queryParams();
            String term = req.queryParams("term");
            Gson gson = new Gson();
            /* Search for actual location data. */
            if (reqParams.contains("full")) {
                List<Map<String, Object>> data = getLocations(term);
                return gson.toJson(data);
            } else {
                /* Search for prefix matching strings. */
                List<String> matches = getLocationsByPrefix(term);
                return gson.toJson(matches);
            }
        });

        /* Define map application redirect */
        get("/", (request, response) -> {
            response.redirect("/map.html", 301);
            return true;
        });
    }

    /**
     * Validate & return a parameter map of the required request parameters.
     * Requires that all input parameters are doubles.
     *
     * @param req            HTTP Request
     * @param requiredParams TestParams to validate
     * @return A populated map of input parameter to it's numerical value.
     */
    private static HashMap<String, Double> getRequestParams(
            spark.Request req, String[] requiredParams) {
        Set<String> reqParams = req.queryParams();
        HashMap<String, Double> params = new HashMap<>();
        for (String param : requiredParams) {
            if (!reqParams.contains(param)) {
                halt(HALT_RESPONSE, "Request failed - parameters missing.");
            } else {
                try {
                    params.put(param, Double.parseDouble(req.queryParams(param)));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    halt(HALT_RESPONSE, "Incorrect parameters - provide numbers.");
                }
            }
        }
        return params;
    }


    /**
     * Handles raster API calls, queries for tiles and rasters the full image. <br>
     * <p>
     * The rastered photo must have the following properties:
     * <ul>
     * <li>Has dimensions of at least w by h, where w and h are the user viewport width
     * and height.</li>
     * <li>The tiles collected must cover the most longitudinal distance per pixel
     * possible, while still covering less than or equal to the amount of
     * longitudinal distance per pixel in the query box for the user viewport size. </li>
     * <li>Contains all tiles that intersect the query bounding box that fulfill the
     * above condition.</li>
     * <li>The tiles must be arranged in-order to reconstruct the full image.</li>
     * <li>If a current route exists, lines of width ROUTE_STROKE_WIDTH_PX and of color
     * ROUTE_STROKE_COLOR are drawn between all nodes on the route in the rastered photo.
     * </li>
     * </ul>
     * Additional image about the raster is returned and is to be included in the Json response.
     * </p>
     *
     * @param params Map of the HTTP GET request's query parameters - the query bounding box and
     *               the user viewport width and height.
     * @param os     An OutputStream that the resulting png image should be written to.
     * @return A map of parameters for the Json response as specified:
     * "raster_ul_lon" -> Double, the bounding upper left longitude of the rastered image <br>
     * "raster_ul_lat" -> Double, the bounding upper left latitude of the rastered image <br>
     * "raster_lr_lon" -> Double, the bounding lower right longitude of the rastered image <br>
     * "raster_lr_lat" -> Double, the bounding lower right latitude of the rastered image <br>
     * "raster_width"  -> Double, the width of the rastered image <br>
     * "raster_height" -> Double, the height of the rastered image <br>
     * "depth"         -> Double, the 1-indexed quadtree depth of the nodes of the rastered image.
     * Can also be interpreted as the length of the numbers in the image string. <br>
     * "query_success" -> Boolean, whether an image was successfully rastered. <br>
     * @see #REQUIRED_RASTER_REQUEST_PARAMS
     */
    public static Map<String, Object> getMapRaster(Map<String, Double> params, OutputStream os) {
        QuadTree t = new QuadTree();
        HashMap<String, Object> rasteredImageParams = new HashMap<>();
        double dpp = Math.abs((params.get("lrlon") - params.get("ullon")) / (params.get("w")));
        ArrayList<NodeLatHolder> nodes = t.returnTilesFor(dpp, params.get("ullat"),
                params.get("ullon"), params.get("lrlat"), params.get("lrlon"));
        Integer rasterwidth = nodes.get(0).getWidth();
        Integer rasterheight = nodes.size() * 256;
        Integer depth = nodes.get(0).getHeigh();
        Double rasterullon = nodes.get(0).returnFirstNode().getUllong();
        Double rasterullat = nodes.get(0).returnFirstNode().getUllat();
        Double rasterlrlon = nodes.get(nodes.size() - 1).returnLastNode().getLrlong();
        Double rasterlrlat = nodes.get(nodes.size() - 1).returnLastNode().getLrlat();
        rasteredImageParams.put("raster_width", rasterwidth);
        rasteredImageParams.put("raster_height", rasterheight);
        rasteredImageParams.put("depth", depth);
        rasteredImageParams.put("raster_ul_lon", rasterullon);
        rasteredImageParams.put("raster_ul_lat", rasterullat);
        rasteredImageParams.put("raster_lr_lon", rasterlrlon);
        rasteredImageParams.put("raster_lr_lat", rasterlrlat);
        rasteredImageParams.put("query_success", true);
        BufferedImage result = new BufferedImage(rasterwidth, rasterheight,
                BufferedImage.TYPE_INT_RGB);
        Graphics gg = result.getGraphics();
        int x = 0;
        int y = 0;
        for (int i = 0; i < nodes.size(); i++) {
            Iterator<QuadTreeNode> iter = nodes.get(i).returnIterator();


            while (iter.hasNext()) {
                QuadTreeNode qnode = iter.next();

                gg.drawImage(GetFile.getFile(qnode.toFileString()), x, y, null);
                x = x + 256;
            }
            y = y + 256;
            x = 0;
        }
        double convertLong = rasterwidth / (Math.abs(rasterullon - rasterlrlon));
        double convertLat = rasterheight / (Math.abs(rasterullat - rasterlrlat));

        Stroke stroked = new BasicStroke(MapServer.ROUTE_STROKE_WIDTH_PX,
                BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        ((Graphics2D) gg).setStroke(stroked);
        gg.setColor(ROUTE_STROKE_COLOR);

        if (goodPath != null && goodPath.size() > 0) {

            for (int i = 1; i < goodPath.size(); i++) {
                GraphNode n1 = g.getNode(goodPath.get(i - 1));
                GraphNode n2 = g.getNode(goodPath.get(i));


                gg.drawLine(((int) (((-rasterullon + n1.getLongitude()) * convertLong))),
                        ((int) (((rasterullat - n1.getLattiude()) * convertLat))),
                        ((int) (((-rasterullon + n2.getLongitude()) * convertLong))),
                        ((int) (((rasterullat - n2.getLattiude()) * convertLat))));
            }
        }


        try {
            ImageIO.write(result, "png", os);
        } catch (IOException e) {
            e.printStackTrace();
        }


        return rasteredImageParams;
    }

    /**
     * Searches for the shortest route satisfying the input request parameters, sets it to be the
     * current route, and returns a <code>LinkedList</code> of the route's node ids for testing
     * purposes. <br>
     * The route should start from the closest node to the start point and end at the closest node
     * to the endpoint. Distance is defined as the euclidean between two points (lon1, lat1) and
     * (lon2, lat2).
     *
     * @param params from the API call described in REQUIRED_ROUTE_REQUEST_PARAMS
     * @return A LinkedList of node ids from the start of the route to the end.
     */
    public static LinkedList<Long> findAndSetRoute(Map<String, Double> params) {


        goodPath = g.getShortestPath(params.get(REQUIRED_ROUTE_REQUEST_PARAMS[0]),
                params.get(REQUIRED_ROUTE_REQUEST_PARAMS[1]),
                params.get(REQUIRED_ROUTE_REQUEST_PARAMS[2]),
                params.get(REQUIRED_ROUTE_REQUEST_PARAMS[3]));


        return goodPath;

    }

    /**
     * Clear the current found route, if it exists.
     */
    public static void clearRoute() {
        goodPath.clear();
    }

    /**
     * In linear time, collect all the names of OSM locations that prefix-match the query string.
     *
     * @param prefix Prefix string to be searched for. Could be any case, with our without
     *               punctuation.
     * @return A <code>List</code> of the full names of locations whose cleaned name matches the
     * cleaned <code>prefix</code>.
     */
    public static List<String> getLocationsByPrefix(String prefix) {
        return new LinkedList<>();
    }

    /**
     * Collect all locations that match a cleaned <code>locationName</code>, and return
     * information about each node that matches.
     *
     * @param locationName A full name of a location searched for.
     * @return A list of locations whose cleaned name matches the
     * cleaned <code>locationName</code>, and each location is a map of parameters for the Json
     * response as specified: <br>
     * "lat" -> Number, The latitude of the node. <br>
     * "lon" -> Number, The longitude of the node. <br>
     * "name" -> String, The actual name of the node. <br>
     * "id" -> Number, The id of the node. <br>
     */
    public static List<Map<String, Object>> getLocations(String locationName) {
        return new LinkedList<>();
    }


}
