import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.HashSet;
import java.util.LinkedList;


import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

/**
 * Wraps the parsing functionality of the MapDBHandler as an example.
 * You may choose to add to the functionality of this class if you wish.
 *
 * @author Alan Yao
 */
public class GraphDB {

    private HashMap<String, GraphNode> uncleanGraph;
    private HashMap<Long, GraphNode> cleanGraph;


    private GraphNode start = null;
    private GraphNode end = null;


    /**
     * Example constructor shows how to create and start an XML parser.
     *
     * @param dbpath Path to the XML file to be parsed.
     */
    public GraphDB(String dbpath) {


        uncleanGraph = new HashMap<>();
        cleanGraph = new HashMap<>();
        try {
            File inputFile = new File(dbpath);
            SAXParserFactory factory = SAXParserFactory.newInstance();
            SAXParser saxParser = factory.newSAXParser();
            MapDBHandler maphandler = new MapDBHandler(this);
            saxParser.parse(inputFile, maphandler);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        clean();
    }

    /**
     * Helper to process strings into their "cleaned" form, ignoring punctuation and capitalization.
     *
     * @param s Input string.
     * @return Cleaned string.
     */
    static String cleanString(String s) {
        return s.replaceAll("[^a-zA-Z ]", "").toLowerCase();
    }

    /**
     * Remove nodes with no connections from the graph.
     * While this does not guarantee that any two nodes in the remaining graph are connected,
     * we can reasonably assume this since typically roads are connected.
     */
    private void clean() {


        Iterator unfilteredNodes = uncleanGraph.entrySet().iterator();

        while (unfilteredNodes.hasNext()) {
            Map.Entry<String, GraphNode> kvPair = ((Map.Entry) unfilteredNodes.next());

            if (kvPair.getValue().numConnecitons() != 0) {
                cleanGraph.put(Long.parseLong(kvPair.getKey()), kvPair.getValue());
            }


        }


        uncleanGraph.clear(); //destroy old unclean graph


    }

    public void addNode(GraphNode newNode) {
        uncleanGraph.put(newNode.getID(), newNode);
    }

    public GraphNode getNodeUnclean(String nodeKey) {
        if (!uncleanGraph.containsKey(nodeKey)) {
            throw new Error("key is bad: " + nodeKey + " unclean size : " + uncleanGraph.size());
        }
        return uncleanGraph.get(nodeKey);
    }

    public GraphNode getNode(Long nodeKey) {
        return cleanGraph.get(nodeKey);
    }


    /**
     * test stat: g.setNode(37.865728,-122.255065, true);
     *
     * @param lat
     * @param lon
     * @param setStart true if start node false if end node
     */
    public void setNode(double lat, double lon, boolean setStart) {
        GraphNode check = new GraphNode(0, 0, "JoshHugIsTheBestTeacher");
        Double checkD = calcDistance(1000000, 1000000, 0, 0);


        Iterator filteredNodes = cleanGraph.entrySet().iterator();

        while (filteredNodes.hasNext()) {
            Map.Entry<String, GraphNode> kvPair = ((Map.Entry) filteredNodes.next());
            double D = calcDistance(lat, lon, kvPair.getValue().getLattiude(),
                    kvPair.getValue().getLongitude());


            if (D < checkD) {
                checkD = D;

                check = kvPair.getValue();
            }


        }

        if (setStart) {
            start = check;
            // System.out.println("start: " + start.toString());
        } else {
            end = check;
            //System.out.println("end: " + end.toString());
        }
    }

    /**
     * returns euclidian distance to the end point
     *
     * @param v
     * @return distance
     */
    private double hueresticFunc(GraphNode v) {
        if (end == null || v == null) {
            throw new NullPointerException();
        }

        return Math.sqrt(Math.pow(Math.abs(v.getLattiude()
                - end.getLattiude()), 2)
                + Math.pow(Math.abs(v.getLongitude() - end.getLongitude()), 2));
    }

    public LinkedList<Long> getShortestPath(double slat, double slong, double elat, double elong) {

        // get ready for the dankest algorithm in CS61b

        HashMap<String, GraphNode> shortestPath = new HashMap<>();
        PriorityQueue<GraphNode> mapQue = new PriorityQueue<>();
        HashSet<GraphNode> visitedNodes = new HashSet<>();

        start = null;
        end = null; // set nodes to 0

        setNode(slat, slong, true);
        setNode(elat, elong, false);

        if (start == null || end == null) {
            throw new NullPointerException(); // cannot have null nodes
        }

        if (start.equals(end)) { // if user clicks the same location
            return null;
        }


        start.setPriority(hueresticFunc(start));
        mapQue.add(start);
        GraphNode curNode = start;

        while (!curNode.equals(end)) {


            curNode = mapQue.remove();


            visitedNodes.add(curNode);

            double oldDistance = curNode.getDistanceFromStart();


            for (GraphNode i : curNode.getConnections()) {

                double newDistance = oldDistance + calcDistance(curNode, i);
                double pri = hueresticFunc(i) + newDistance;


                if (!visitedNodes.contains(i) && (pri < i.getPriority())) {
                    i.setDistanceFromStart(newDistance);


                    i.setPriority(pri);
                    shortestPath.put(i.getId(), curNode);
                    mapQue.add(i);


                }
            }


        }


        curNode = end;
        LinkedList<Long> retList = new LinkedList<>();
        while (curNode != null) {
            retList.addFirst(Long.parseLong(curNode.getId()));
            curNode = shortestPath.get(curNode.getId());

        }
        start = null;
        end = null;
        clearEverything();

        return retList;
    }

    public double calcDistance(GraphNode a, GraphNode b) {

        return Math.sqrt(Math.pow(b.getLattiude()
                - a.getLattiude(), 2)
                + Math.pow(b.getLongitude()
                - a.getLongitude(), 2));

    }

    private double calcDistance(double lat1, double long1, double lat2, double long2) {

        return Math.sqrt(Math.pow(lat1 - lat2, 2)
                + Math.pow(long1 - long2, 2));

    }

    public void clearEverything() {
        // cleanGraph = new HashMap<>();
        // uncleanGraph = new HashMap<>();

        Iterator unfilteredNodes = cleanGraph.entrySet().iterator();

        while (unfilteredNodes.hasNext()) {
            Map.Entry<String, GraphNode> kvPair = ((Map.Entry) unfilteredNodes.next());


            kvPair.getValue().setPriority(Double.MAX_VALUE);
            kvPair.getValue().setDistanceFromStart(0);


        }
        start = null;
        end = null; // set nodes to 0
    }
}
